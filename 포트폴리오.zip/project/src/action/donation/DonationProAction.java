package action.donation;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.campaign.CampaignUpdateService;
import svc.donation.DonationService;
import svc.login.DeleteMemberChkService;
import vo.ActionForward;
import vo.donation.DonationBean;

public class DonationProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String member_id = (String)session.getAttribute("id");
		
		DonationBean donationInfo = new DonationBean();
		
		int campaign_no = Integer.parseInt(request.getParameter("campaign_no"));
		
		long donation_money1 = 0;
		String donation_money2 = "";
		if (request.getParameter("donation_money1").equalsIgnoreCase("A")) {
			donation_money1 = Long.parseLong(request.getParameter("donation_money2"));
			donation_money2 = request.getParameter("donation_money2");
		} else {
			donation_money1 = Long.parseLong(request.getParameter("donation_money1"));
			donation_money2 = request.getParameter("donation_money1");
		}
		
		String pay_type = "";
		if (request.getParameter("pay_type").equalsIgnoreCase("card")) {
			pay_type = "C";
		} else if (request.getParameter("pay_type").equalsIgnoreCase("bank")) {
			pay_type = "B";
		}
		
		String donation_type = "";
		if (request.getParameter("card_donation_type").equalsIgnoreCase("temporary")) {
			donation_type = "T";
		} else if (request.getParameter("card_donation_type").equalsIgnoreCase("regularly")) {
			donation_type = "R";
		}
		
		
		donationInfo.setDonation_campaign_no(campaign_no);
		donationInfo.setDonation_member_id(member_id);
		donationInfo.setDonation_money(donation_money2);
		donationInfo.setDonation_type(donation_type);
		donationInfo.setPay_type(pay_type);
		
		DeleteMemberChkService memberChkService = new DeleteMemberChkService();
		String member_category = memberChkService.isDeleteMemberCategory(member_id);
		
		if (pay_type.equalsIgnoreCase("C")) {
			DonationService donationService = new DonationService();
			boolean donationSuccess = false;
			if (member_category.equalsIgnoreCase("normal")) {
				donationSuccess = donationService.donationCardNormalMember(donationInfo);
			} else if (member_category.equalsIgnoreCase("comgrp")) {
				donationSuccess = donationService.donationCardComgrpMember(donationInfo);
			}
			if (!donationSuccess) {
				out.println("<script>");
				out.println("alert('기부에 실패하였습니다.');");
				out.println("history.back()");
				out.println("</script>");
			} else {
				CampaignUpdateService campaignUpdateService = new CampaignUpdateService();
				boolean campaignUpdateSuccess = campaignUpdateService.campaignUpdateAllFundRaised(campaign_no, donation_money1);
				
				if (!campaignUpdateSuccess) {
					out.println("<script>");
					out.println("alert('후원금에 기부 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					forward = new ActionForward("donationCard.donation", false);
				}
			}
		} else if (pay_type.equalsIgnoreCase("B")) {
			DonationService donationService = new DonationService();
			boolean donationSuccess = false;
			if (member_category.equalsIgnoreCase("normal")) {
				donationSuccess = donationService.donationBankNormalMember(donationInfo);
			} else if (member_category.equalsIgnoreCase("comgrp")) {
				donationSuccess = donationService.donationBankComgrpMember(donationInfo);
			}
			if (!donationSuccess) {
				out.println("<script>");
				out.println("alert('기부에 실패하였습니다.');");
				out.println("history.back()");
				out.println("</script>");
			} else {
				forward = new ActionForward("donationBank.donation", false);
			}
		}
		return forward;
	}

}

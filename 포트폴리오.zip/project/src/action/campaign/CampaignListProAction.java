package action.campaign;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignListService;
import svc.donation.MyDonationInfoService;
import vo.ActionForward;
import vo.campaign.CampaignBean;

public class CampaignListProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		CampaignListService campaignListService = new CampaignListService();
		ArrayList<CampaignBean> campaignList = campaignListService.getCampaign();
		
		request.setAttribute("campaignList", campaignList);
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		if (id != null) {
			AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
			String admin_grade = adminGradeChkService.isAdminGrade(id);
			if (admin_grade != "") {
				forward = new ActionForward("adminCampaign.page", false);
			} else {
				MyDonationInfoService myDonationInfoService = new MyDonationInfoService();
				ArrayList<String> donation_money = new ArrayList<String>();
				String money = "";
				for (int i = 0 ; i < campaignList.size() ; i++) {
					int campaign_no = campaignList.get(i).getCampaign_no();
					money = myDonationInfoService.getMyDonationMoney(id, campaign_no);
					donation_money.add(money);
				}
				request.setAttribute("donation_money", donation_money);
				
				forward = new ActionForward("memberCampaign.page", false);
			}
		} else {
			forward = new ActionForward("campaign.page", false);
		}
		return forward;
	}

}

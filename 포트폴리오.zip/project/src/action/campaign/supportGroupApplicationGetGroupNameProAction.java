package action.campaign;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.campaign.CampaignListService;
import svc.campaign.SupportGroupGetNameService;
import vo.ActionForward;

public class supportGroupApplicationGetGroupNameProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String campaign_no = request.getParameter("campaign_no");
		String id = request.getParameter("member_id");
		
		SupportGroupGetNameService supportGroupGetNameService = new SupportGroupGetNameService();
		String group_name = supportGroupGetNameService.getGroupName(id);
		
		if (group_name == "") {
			out.println("<script>");
			out.println("alert('단체명 가져오기에 실패하였습니다.\\n관리자에게 문의해주세요.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			CampaignListService campaignListService = new CampaignListService();
			boolean suppotGroupOverlapChk = campaignListService.supportGroupOverlapChk(campaign_no, group_name);
			
			if (!suppotGroupOverlapChk) {
			request.setAttribute("group_name", group_name);
			request.setAttribute("campaign_no", campaign_no);
			
			forward = new ActionForward("supportGroupApplication.page", false);
			} else {
				out.println("<script>");
				out.println("alert('이미 이 캠페인에 지원단체로 등록하셨습니다.\\n관리자 승인을 기다려주세요.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			}
		}
		return forward;
	}

}

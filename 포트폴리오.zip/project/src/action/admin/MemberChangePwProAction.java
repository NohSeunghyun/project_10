package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.ChangeInfoMemberChkService;
import svc.login.ChangePwService;
import vo.ActionForward;

public class MemberChangePwProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("member_id");
		String changePw = request.getParameter("changePw");
		
		ChangeInfoMemberChkService changeInfoMemberChkService = new ChangeInfoMemberChkService();
		String category = changeInfoMemberChkService.isChangeInfoMemberCategory(id);
		
		if (category == "normal") {
			ChangePwService changePwService = new ChangePwService();
			boolean isNormalChangePwSuccess = changePwService.isNormalChangePw(id, changePw);
			
			if (!isNormalChangePwSuccess) {
				out.println("<script>");
				out.println("alert('비밀번호 변경에 실패하였습니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				forward = new ActionForward("memberChangePwSuccess.page", false);
			}
		} else if (category == "comgrp") {
			ChangePwService changePwService = new ChangePwService();
			boolean isComgrpChangePwSuccess = changePwService.isComgrpChangePw(id, changePw);
			
			if (!isComgrpChangePwSuccess) {
				out.println("<script>");
				out.println("alert('비밀번호 변경에 실패하였습니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				forward = new ActionForward("memberChangePwSuccess.page", false);
			}
		}
		return forward;
	}

}

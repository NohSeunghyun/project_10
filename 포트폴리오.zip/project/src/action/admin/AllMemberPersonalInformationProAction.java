package action.admin;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.AllMemberPersonalInformationService;
import vo.ActionForward;
import vo.login.AdminMemberBean;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

public class AllMemberPersonalInformationProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("admin_id");
		String phone = request.getParameter("admin_phone1") + "-" + request.getParameter("admin_phone2") + "-" + request.getParameter("admin_phone3");
		String pw = request.getParameter("admin_pw");
				
		AllMemberPersonalInformationService allMemberPersonalInformationService = new AllMemberPersonalInformationService();
		String successPwPhone = allMemberPersonalInformationService.chkPwPhone(id, pw, phone);
		
		if (successPwPhone == "") {
			out.println("<script>");
			out.println("alert('입력하신 정보가 일치하지 않습니다.\\n확인 후 다시 시도해주세요.');");
			out.println("history.back();");
			out.println("</script>");
		} else if (successPwPhone == "pw") {
			out.println("<script>");
			out.println("alert('휴대폰번호가 일치하지 않습니다.\\n확인 후 다시 시도해주세요.');");
			out.println("history.back();");
			out.println("</script>");
		} else if (successPwPhone == "phone") {
			out.println("<script>");
			out.println("alert('비밀번호가 일치하지 않습니다.\\n확인 후 다시 시도해주세요.');");
			out.println("history.back();");
			out.println("</script>");
		} else if (successPwPhone == "pwPhone") {
			allMemberPersonalInformationService = new AllMemberPersonalInformationService();
			ArrayList<NormalMemberBean> normalMemberList = allMemberPersonalInformationService.getNormalMemberList();
			ArrayList<CompanyGroupMemberBean> companyGroupMemberList = allMemberPersonalInformationService.getComgrpMemberList();
			ArrayList<AdminMemberBean> adminMemberList = allMemberPersonalInformationService.getAdminMemberList();
			
			request.setAttribute("normalMemberList", normalMemberList);
			request.setAttribute("comgrpMemberList", companyGroupMemberList);
			request.setAttribute("adminMemberList", adminMemberList);
			
			forward = new ActionForward("allMemberPersonalInformationForm.page", false);
		}
		return forward;
	}

}

package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.PersonalInformationService;
import vo.ActionForward;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

public class PersonalInformationProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		PersonalInformationService personalInformationService = new PersonalInformationService();
		String successPW = personalInformationService.chkPW(id, pw);
		
		if (successPW == "") {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('비밀번호가 일치하지 않습니다.');");
			out.println("history.back();");
			out.println("</script>");
		} else if (successPW == "normal") {
			personalInformationService = new PersonalInformationService();
			NormalMemberBean info = personalInformationService.normalInfo(id);
			request.setAttribute("info", info);
			forward = new ActionForward("/normalMemberPersonalInformationForm.page", false);
		} else if (successPW == "comgrp") {
			personalInformationService = new PersonalInformationService();
			CompanyGroupMemberBean info = personalInformationService.comgrpInfo(id);
			request.setAttribute("info", info);
			forward = new ActionForward("/comgrpMemberPersonalInformationForm.page", false);
		}
		return forward;
	}

}

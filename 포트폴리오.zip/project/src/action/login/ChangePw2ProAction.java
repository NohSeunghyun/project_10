package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.ChangePwMemberChkService;
import svc.login.ChangePwService;
import vo.ActionForward;

public class ChangePw2ProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("member_id");
		String changePw = request.getParameter("changePw");
		
		ChangePwMemberChkService changePwMemberChkService = new ChangePwMemberChkService();
		String category = changePwMemberChkService.isChangePwMemberCategory(id);
		
		if (category == "normal") {
			ChangePwService changePwService = new ChangePwService();
			boolean isNormalChangePwSuccess = changePwService.isNormalChangePw(id, changePw);
			if (!isNormalChangePwSuccess) {
				out.println("<script>");
				out.println("alert('비밀번호 변경에 실패하였습니다.');");
				out.println("history.back();");
				out.println("</script>");
			} else {
				forward = new ActionForward("changePwSuccess.page", false);
			}
		} else if (category == "comgrp") {
			ChangePwService changePwService = new ChangePwService();
			boolean isComgrpChangePwSuccess = changePwService.isComgrpChangePw(id, changePw);
			if (!isComgrpChangePwSuccess) {
				out.println("<script>");
				out.println("alert('비밀번호 변경에 실패하였습니다.');");
				out.println("history.back();");
				out.println("</script>");
			} else {
				forward = new ActionForward("changePwSuccess.page", false);
			}
		} else {
			out.println("<script>");
			out.println("alert('현재 비밀번호가 일치하지 않습니다.');");
			out.println("history.back();");
			out.println("</script>");
		}
		return forward;
	}

}

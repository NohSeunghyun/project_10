package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import vo.login.AdminMemberBean;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

import static db.JdbcUtil.*;

public class AdminDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";

	private static AdminDAO adminDAO;

	public static AdminDAO getInstance() {
		if (adminDAO == null) {
			adminDAO = new AdminDAO();
		}
		return adminDAO;
	}

	public void setConnection(Connection con) {
		this.con = con;
	}

	//관리자 모든회원 정보조회 전 비밀번호, 휴대폰번호 일치 확인
	public String chkPwPhone(String id, String pw, String phone) {
		String successPwPhone = "";
		try {
			sql = "select admin_pw, admin_phone from admin_tbl where admin_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				if (pw.equals(rs.getString("admin_pw"))) {
					successPwPhone = "pw";
					if (phone.equals(rs.getString("admin_phone"))) {
						successPwPhone = "pwPhone";
					}
				} else if (phone.equals(rs.getString("admin_phone"))) {
					successPwPhone = "phone";
				}
			}
		} catch (Exception e) {
			System.out.println("isupdateComgrpMember 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return successPwPhone;
	}

	//모든 일반회원 정보조회
	public ArrayList<NormalMemberBean> getNormalMemberList() {
		ArrayList<NormalMemberBean> normalMemberList = new ArrayList<NormalMemberBean>();
		try {
			sql = "select * from normal_member_tbl order by normal_member_grade";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			NormalMemberBean normalMember = null;
			
			while (rs.next()) {
				normalMember = new NormalMemberBean();
				
				normalMember.setNormal_member_id(rs.getString("normal_member_id"));
				normalMember.setNormal_member_pw(rs.getString("normal_member_pw"));
				normalMember.setNormal_member_name(rs.getString("normal_member_name"));
				normalMember.setNormal_member_birth(rs.getString("normal_member_birth"));
				normalMember.setNormal_member_phone(rs.getString("normal_member_phone"));
				String gender = "";
				if (rs.getString("normal_member_gender").equalsIgnoreCase("M")) {
					gender = "남";
				} else if (rs.getString("normal_member_gender").equalsIgnoreCase("F")) {
					gender = "여";
				}
				normalMember.setNormal_member_gender(gender);
				normalMember.setNormal_member_email(rs.getString("normal_member_email"));
				normalMember.setNormal_member_date(rs.getDate("normal_member_date"));
				String grade = "";
				if (rs.getString("normal_member_grade").equalsIgnoreCase("C")) {
					grade = "Silver";
				} else if (rs.getString("normal_member_grade").equalsIgnoreCase("B")) {
					grade = "Gold";
				} else if (rs.getString("normal_member_grade").equalsIgnoreCase("A-")) {
					grade = "Platinum";
				} else if (rs.getString("normal_member_grade").equalsIgnoreCase("A")) {
					grade = "Diamond";
				}
				normalMember.setNormal_member_grade(grade);
				
				normalMemberList.add(normalMember);
			}
		} catch (Exception e) {
			System.out.println("getNormalMemberList 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return normalMemberList;
	}

	//모든 기업/단체회원 정보조회
	public ArrayList<CompanyGroupMemberBean> getComgrpMemberList() {
		ArrayList<CompanyGroupMemberBean> comgrpMemberList = new ArrayList<CompanyGroupMemberBean>();
		try {
			sql = "select * from comgrp_member_tbl order by comgrp_member_grade";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			CompanyGroupMemberBean comgrpMember = null;
			
			while (rs.next()) {
				comgrpMember = new CompanyGroupMemberBean();
				
				comgrpMember.setComgrp_member_id(rs.getString("comgrp_member_id"));
				comgrpMember.setComgrp_member_pw(rs.getString("comgrp_member_pw"));
				String category = "";
				if (rs.getString("comgrp_member_category").equalsIgnoreCase("C")) {
					category = "기업";
				} else if (rs.getString("comgrp_member_category").equalsIgnoreCase("G")) {
					category = "단체";
				}
				comgrpMember.setComgrp_member_category(category);
				comgrpMember.setComgrp_member_name(rs.getString("comgrp_member_name"));
				comgrpMember.setComgrp_manager_name(rs.getString("comgrp_manager_name"));
				comgrpMember.setComgrp_member_companyno(rs.getString("comgrp_member_companyno"));
				comgrpMember.setComgrp_manager_phone(rs.getString("comgrp_manager_phone"));
				comgrpMember.setComgrp_member_email(rs.getString("comgrp_member_email"));
				comgrpMember.setComgrp_member_date(rs.getDate("comgrp_member_date"));
				String grade = "";
				if (rs.getString("comgrp_member_grade").equalsIgnoreCase("C")) {
					grade = "Silver";
				} else if (rs.getString("comgrp_member_grade").equalsIgnoreCase("B")) {
					grade = "Gold";
				} else if (rs.getString("comgrp_member_grade").equalsIgnoreCase("A-")) {
					grade = "Platinum";
				} else if (rs.getString("comgrp_member_grade").equalsIgnoreCase("A")) {
					grade = "Diamond";
				}
				comgrpMember.setComgrp_member_grade(grade);
				
				comgrpMemberList.add(comgrpMember);
			}
		} catch (Exception e) {
			System.out.println("getComgrpMemberList 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return comgrpMemberList;
	}

	//모든 관리자 정보조회
	public ArrayList<AdminMemberBean> getAdminMemberList() {
		ArrayList<AdminMemberBean> adminMemberList = new ArrayList<AdminMemberBean>();
		try {
			sql = "select * from admin_tbl order by admin_grade";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			AdminMemberBean adminMember = null;
			
			while(rs.next()) {
				adminMember = new AdminMemberBean();
				
				adminMember.setAdmin_id(rs.getString("admin_id"));
				adminMember.setAdmin_pw(rs.getString("admin_pw"));
				adminMember.setAdmin_name(rs.getString("admin_name"));
				adminMember.setAdmin_phone(rs.getString("admin_phone"));
				adminMember.setAdmin_date(rs.getDate("admin_date"));
				adminMember.setAdmin_grade(rs.getString("admin_grade"));
				
				adminMemberList.add(adminMember);
			}
		} catch (Exception e) {
			System.out.println("getAdminMemberList 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return adminMemberList;
	}

	//관리자 등급 조회
	public String isAdminGrade(String admin_id) {
		String admin_grade = "";
		try {
			sql = "select admin_grade from admin_tbl where admin_id = '" + admin_id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				admin_grade = rs.getString("admin_grade");
			}
		} catch (Exception e) {
			System.out.println("isAdminGrade 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return admin_grade;
	}

	//관리자 회원비밀번호 변경 전 회원 구분
	public String isAdminMemberChangePwCategory(String id) {
		String isAdminMemberChangePwCategory = "";
		try {
			sql = "select * from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
					isAdminMemberChangePwCategory = "normal";
			} else {
				sql = "select * from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
						isAdminMemberChangePwCategory = "comgrp";
				}
			}
		} catch (Exception e) {
			System.out.println("isAdminMemberChangePwCategory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return isAdminMemberChangePwCategory;
	}

	//일반회원 등급 수정
	public int isNormalChangeGrade(String id, String grade) {
		int normalChangeGradeUpdateCount = 0;
		try {
			sql = "update normal_member_tbl set normal_member_grade = '" + grade + "' where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			normalChangeGradeUpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isNormalChangeGrade 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return normalChangeGradeUpdateCount;
	}

	//기업/단체회원 등급 수정
	public int isComgrpChangeGrade(String id, String grade) {
		int comgrpChangeGradeUpdateCount = 0;
		try {
			sql = "update comgrp_member_tbl set comgrp_member_grade = '" + grade + "' where comgrp_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			comgrpChangeGradeUpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isNormalChangeGrade 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return comgrpChangeGradeUpdateCount;
	}

	//일반회원 개인정보 수정 전 조회
	public NormalMemberBean adminNormalMemberInfo(String id) {
		NormalMemberBean normalInfo = null;
		try {
			sql = "select * from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				normalInfo = new NormalMemberBean();
				
				normalInfo.setNormal_member_id(id);
				normalInfo.setNormal_member_name(rs.getString("normal_member_name"));
				normalInfo.setNormal_member_birth(rs.getString("normal_member_birth"));
				normalInfo.setNormal_member_phone(rs.getString("normal_member_phone"));
				normalInfo.setNormal_member_gender(rs.getString("normal_member_gender"));
				normalInfo.setNormal_member_email(rs.getString("normal_member_email"));
				normalInfo.setNormal_member_date(rs.getDate("normal_member_date"));
				normalInfo.setNormal_member_grade(rs.getString("normal_member_grade"));
			}
		} catch (Exception e) {
			System.out.println("adminNormalMemberInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return normalInfo;
	}

	//기업/단체회원 개인정보 수정 전 조회
	public CompanyGroupMemberBean adminComgrpMemberInfo(String id) {
		CompanyGroupMemberBean comgrpInfo = null;
		try {
			sql = "select * from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				comgrpInfo = new CompanyGroupMemberBean();
				
				comgrpInfo.setComgrp_member_id(id);
				comgrpInfo.setComgrp_member_category(rs.getString("comgrp_member_category"));
				comgrpInfo.setComgrp_member_name(rs.getString("comgrp_member_name"));
				comgrpInfo.setComgrp_member_companyno(rs.getString("comgrp_member_companyno"));
				comgrpInfo.setComgrp_manager_name(rs.getString("comgrp_manager_name"));
				comgrpInfo.setComgrp_manager_phone(rs.getString("comgrp_manager_phone"));
				comgrpInfo.setComgrp_member_email(rs.getString("comgrp_member_email"));
				comgrpInfo.setComgrp_member_date(rs.getDate("comgrp_member_date"));
				comgrpInfo.setComgrp_member_grade(rs.getString("comgrp_member_grade"));
			}
		} catch (Exception e) {
			System.out.println("adminComgrpMemberInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return comgrpInfo;
	}

	//관리자 비밀번호 변경
	public int isAdminMemberChangePw(String id, String changePw) {
		int AdminMemberChangePwUpdateCount = 0;
		try {
			sql = "update admin_tbl set admin_pw = '" + changePw + "' where admin_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			AdminMemberChangePwUpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isAdminMemberChangePw 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return AdminMemberChangePwUpdateCount;
	}

	//관리자 등급 변경
	public int isAdminMemberChangeGrade(String id, String changeGrade) {
		int AdminMemberChangeGradeUpdateCount = 0;
		try {
			sql = "update admin_tbl set admin_grade = '" + changeGrade + "' where admin_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			AdminMemberChangeGradeUpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isAdminMemberChangeGrade 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return AdminMemberChangeGradeUpdateCount;
	}

	//관리자 개인정보 수정 전 조회
	public AdminMemberBean adminMemberInfo(String id) {
		AdminMemberBean adminInfo = null;
		try {
			sql = "select * from admin_tbl where admin_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				adminInfo = new AdminMemberBean();
				
				adminInfo.setAdmin_id(id);
				adminInfo.setAdmin_name(rs.getString("admin_name"));
				adminInfo.setAdmin_phone(rs.getString("admin_phone"));
				adminInfo.setAdmin_date(rs.getDate("admin_date"));
				adminInfo.setAdmin_grade(rs.getString("admin_grade"));
			}
		} catch (Exception e) {
			System.out.println("adminMemberInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return adminInfo;
	}

	//관리자 개인정보 수정
	public int isupdateAdminMember(AdminMemberBean adminMemberBean) {
		int adminMemberUpdateCount = 0;
		try {
			sql = "update admin_tbl set admin_name = ?, admin_phone = ? where admin_id = '" + adminMemberBean.getAdmin_id() + "'";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, adminMemberBean.getAdmin_name());
			pstmt.setString(2, adminMemberBean.getAdmin_phone());
			
			adminMemberUpdateCount = pstmt.executeUpdate();
		}  catch (Exception e) {
			System.out.println("isupdateAdminMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return adminMemberUpdateCount;
	}

	//관리자 삭제
	public int isAdminDelete(String id) {
		int adminDeleteCount = 0;
		try {
			sql = "delete from admin_tbl where admin_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			adminDeleteCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isAdminDelete 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return adminDeleteCount;
	}

	//관리자 추가
	public int joinMemberShip_admin(AdminMemberBean adminMember) {
		int joinMemberShipCount = 0;
		try {
			sql = "insert into admin_tbl values (?, ?, ?, ?, now(), default)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, adminMember.getAdmin_id());
			pstmt.setString(2, adminMember.getAdmin_pw());
			pstmt.setString(3, adminMember.getAdmin_name());
			pstmt.setString(4, adminMember.getAdmin_phone());
			
			joinMemberShipCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("joinMemberShip_admin 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return joinMemberShipCount;
	}
	
}

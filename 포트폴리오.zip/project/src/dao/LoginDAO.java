package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

import static db.JdbcUtil.*;

public class LoginDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";

	private static LoginDAO loginDAO;

	public static LoginDAO getInstance() {
		if (loginDAO == null) {
			loginDAO = new LoginDAO();
		}
		return loginDAO;
	}

	public void setConnection(Connection con) {
		this.con = con;
	}

	//로그인 아이디 확인
	public String isIdChk(String id) {
		String isIdChk = "";
		try {
			sql = "select * from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				isIdChk = "normal";
			} else {
				sql = "select * from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					isIdChk = "comgrp";
				} else {
					sql = "select * from admin_tbl where admin_id = '" + id + "'";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						isIdChk = "admin";
					} else {
						isIdChk = "null";
					}
				}
			}
		} catch (Exception e) {
			System.out.println("isIdChk 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return isIdChk;
	}

	//로그인 패스워드 확인
	public String isPwChk(String id, String isIdChk, String pw) {
		String isPwChk = "false";
		try {
			switch (isIdChk) {
				case "normal" : {
					sql = "select * from normal_member_tbl where normal_member_id = '" + id + "'";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						if (pw.equals(rs.getString("normal_member_pw"))) {
							isPwChk = "Success";
						}
					}
					break;
				}
				case "comgrp" : {
					sql = "select * from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						if (pw.equals(rs.getString("comgrp_member_pw"))) {
							isPwChk = "Success";
						}
					}
					break;
				}
				case "admin" : {
					sql = "select * from admin_tbl where admin_id = '" + id + "'";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						if (pw.equals(rs.getString("admin_pw"))) {
							isPwChk = "Success";
						}
					}
					break;
				}
				default : isPwChk = "Fail";
			}
		} catch (Exception e) {
			System.out.println("isPwChk 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return isPwChk;
	}

	//로그인 성공 후 세션에 담을 해당회원 이름
	public String name(String id) {
		String name = "";
		try {
			sql = "select normal_member_name from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				name = rs.getString("normal_member_name") + " 회원";
			} else {
				sql = "select comgrp_member_name, comgrp_manager_name from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					name = rs.getString("comgrp_member_name") + "의 " + rs.getString("comgrp_manager_name") + " 회원";
				} else {
					sql = "select admin_name from admin_tbl where admin_id = '" + id + "'";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						name = rs.getString("admin_name") + " 관리자";
					}
				}
			}
		} catch (Exception e) {
			System.out.println("name 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return name;
	}
	
	//아이디 중복 확인
	public boolean isIdOverlapChk(String id) {
		boolean isIdOverlapChk = false;
		try {
			sql = "select * from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if(id.equalsIgnoreCase(rs.getString("normal_member_id"))) {
					isIdOverlapChk = true;
				}
			} else {
				sql = "select * from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					if (id.equalsIgnoreCase(rs.getString("comgrp_member_id"))) {
						isIdOverlapChk = true;
					} 
				} else {
					sql = "select * from admin_tbl where admin_id = '" + id + "'";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					if(rs.next()) {
						if (id.equalsIgnoreCase(rs.getString("admin_id"))) {
							isIdOverlapChk = true;
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("isIdOverlapChk 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return isIdOverlapChk;
	}
	
	//일반회원 회원가입
	public int joinMemberShip_normal(NormalMemberBean normalMember) {
		int joinMemberShipCount = 0;
		try {
			sql = "insert into normal_member_tbl values (?, ?, ?, ?, ?, ?, ?, now(), default)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, normalMember.getNormal_member_id());
			pstmt.setString(2, normalMember.getNormal_member_pw());
			pstmt.setString(3, normalMember.getNormal_member_name());
			pstmt.setString(4, normalMember.getNormal_member_birth());
			pstmt.setString(5, normalMember.getNormal_member_phone());
			pstmt.setString(6, normalMember.getNormal_member_gender());
			pstmt.setString(7, normalMember.getNormal_member_email());
			
			joinMemberShipCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("joinMemberShip_normal 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return joinMemberShipCount;
	}
	
	//기업/단체 회원가입
	public int joinMemberShip_comgrp(CompanyGroupMemberBean companyGroupMember) {
		int joinMemberShipCount = 0;
		try {
			sql = "insert into comgrp_member_tbl values (?, ?, ?, ?, ?, ?, ?, ?, now(), default)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, companyGroupMember.getComgrp_member_id());
			pstmt.setString(2, companyGroupMember.getComgrp_member_pw());
			pstmt.setString(3, companyGroupMember.getComgrp_member_category());
			pstmt.setString(4, companyGroupMember.getComgrp_member_name());
			pstmt.setString(5, companyGroupMember.getComgrp_manager_name());
			pstmt.setString(6, companyGroupMember.getComgrp_member_companyno());
			pstmt.setString(7, companyGroupMember.getComgrp_manager_phone());
			pstmt.setString(8, companyGroupMember.getComgrp_member_email());
			
			joinMemberShipCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("joinMemberShip_comgrp 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return joinMemberShipCount;
	}

	//핸드폰번호로 아이디찾기
	public String phoneSearchID(String name, String phone) {
		String searchID = "";
		try {
			sql = "select normal_member_id from normal_member_tbl where normal_member_phone = '" + phone + "' and normal_member_name = '" + name + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				searchID = rs.getString("normal_member_id");
			} else {
				sql = "select comgrp_member_id from comgrp_member_tbl where comgrp_manager_phone = '" + phone + "' and comgrp_manager_name = '" + name + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					searchID = rs.getString("comgrp_member_id");
				} else {
					sql = "select admin_id from admin_tbl where admin_phone = '" + phone + "' and admin_name = '" + name + "'";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						searchID = rs.getString("admin_id");
					}
				}
			}
		} catch (Exception e) {
			System.out.println("phoneSearchID 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return searchID;
	}

	//이메일주소로 아이디찾기
	public String emailSearchID(String name, String email) {
		String searchID = "";
		try {
			sql = "select normal_member_id from normal_member_tbl where normal_member_email = '" + email + "' and normal_member_name = '" + name + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				searchID = rs.getString("normal_member_id");
			} else {
				sql = "select comgrp_member_id from comgrp_member_tbl where comgrp_member_email = '" + email + "' and comgrp_manager_name = '" + name + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					searchID = rs.getString("comgrp_member_id");
				}
			}
		} catch (Exception e) {
			System.out.println("emailSearchID 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return searchID;
	}

	//아이디, 핸드폰번호, 이메일로 비밀번호 찾기
	public String searchPW(String id, String phone, String email) {
		String searchPW = "";
		try {
			sql = "select concat(substr(normal_member_pw, 1, (length(normal_member_pw))-4),'****') as member_pw from normal_member_tbl where normal_member_id = '"+id+"' and normal_member_phone = '" + phone + "' and normal_member_email = '" + email + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				searchPW = rs.getString("member_pw");
			} else {
				sql = "select concat(substr(comgrp_member_pw, 1, (length(comgrp_member_pw))-4),'****') as member_pw from comgrp_member_tbl where comgrp_member_id = '"+id+"' and comgrp_manager_phone = '" + phone + "' and comgrp_member_email = '" + email + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					searchPW = rs.getString("member_pw");
				}
			}
		} catch (Exception e) {
			System.out.println("searchPW 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return searchPW;
	}

	//개인정보조회 전 패스워드 일치를 통한 본인확인
	public String chkPW(String id, String pw) {
		String successPW = "";
		try {
			sql = "select normal_member_pw from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (pw.equals(rs.getString("normal_member_pw"))) {
					successPW = "normal";
				}
			} else {
				sql = "select comgrp_member_pw from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					if (pw.equals(rs.getString("comgrp_member_pw"))) {
						successPW = "comgrp";
					}
				}
			}
		} catch (Exception e) {
			System.out.println("chkPW 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return successPW;
	}

	//일반회원 개인정보 조회
	public NormalMemberBean normalInfo(String id) {
		NormalMemberBean normalInfo = null;
		try {
			sql = "select * from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				normalInfo = new NormalMemberBean();
				
				normalInfo.setNormal_member_id(id);
				normalInfo.setNormal_member_pw(rs.getString("normal_member_pw"));
				normalInfo.setNormal_member_name(rs.getString("normal_member_name"));
				normalInfo.setNormal_member_birth(rs.getString("normal_member_birth"));
				normalInfo.setNormal_member_phone(rs.getString("normal_member_phone"));
				normalInfo.setNormal_member_gender(rs.getString("normal_member_gender"));
				normalInfo.setNormal_member_email(rs.getString("normal_member_email"));
				normalInfo.setNormal_member_date(rs.getDate("normal_member_date"));
				normalInfo.setNormal_member_grade(rs.getString("normal_member_grade"));
			}
		} catch (Exception e) {
			System.out.println("normalInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return normalInfo;
	}

	//기업/단체회원 개인정보 조회
	public CompanyGroupMemberBean comgrpInfo(String id) {
		CompanyGroupMemberBean comgrpInfo = null;
		try {
			sql = "select * from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				comgrpInfo = new CompanyGroupMemberBean();
				
				comgrpInfo.setComgrp_member_id(id);
				comgrpInfo.setComgrp_member_pw(rs.getString("comgrp_member_pw"));
				comgrpInfo.setComgrp_member_category(rs.getString("comgrp_member_category"));
				comgrpInfo.setComgrp_member_name(rs.getString("comgrp_member_name"));
				comgrpInfo.setComgrp_manager_name(rs.getString("comgrp_manager_name"));
				comgrpInfo.setComgrp_member_companyno(rs.getString("comgrp_member_companyno"));
				comgrpInfo.setComgrp_manager_phone(rs.getString("comgrp_manager_phone"));
				comgrpInfo.setComgrp_member_email(rs.getString("comgrp_member_email"));
				comgrpInfo.setComgrp_member_date(rs.getDate("comgrp_member_date"));
				comgrpInfo.setComgrp_member_grade(rs.getString("comgrp_member_grade"));
			}
		} catch (Exception e) {
			System.out.println("comgrpInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return comgrpInfo;
	}

	//비밀번호 변경 전 비밀번호 일치 확인 및 회원구분
	public String isChangePwMemberCategory(String id, String originPw) {
		String isChangePwMemberCategory = "";
		try {
			sql = "select normal_member_pw from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				if (originPw.equals(rs.getString("normal_member_pw"))) {
					isChangePwMemberCategory = "normal";
				}
			} else {
				sql = "select comgrp_member_pw from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					if (originPw.equals(rs.getString("comgrp_member_pw"))) {
						isChangePwMemberCategory = "comgrp";
					}
				}
			}
		} catch (Exception e) {
			System.out.println("isChangePwMemberCategory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return isChangePwMemberCategory;
	}

	//일반회원 비밀번호 변경
	public int isNormalChangePw(String id, String changePw) {
		int normalChangePwUpdateCount = 0;
		try {
			sql = "update normal_member_tbl set normal_member_pw = '" + changePw + "' where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			normalChangePwUpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isNormalChangePw 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return normalChangePwUpdateCount;
	}

	//기업/단체회원 비밀번호 변경
	public int isComgrpChangePw(String id, String changePw) {
		int comgrpChangePwUpdateCount = 0;
		try {
			sql = "update comgrp_member_tbl set comgrp_member_pw = '" + changePw + "' where comgrp_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			comgrpChangePwUpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isComgrpChangePw 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return comgrpChangePwUpdateCount;
	}

	//회원탈퇴 전 회원구분
	public String isDeleteMemberCategory(String id) {
		String isDeleteMemberCategory = "";
		try {
			sql = "select * from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				isDeleteMemberCategory = "normal";
			} else {
				sql = "select * from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					isDeleteMemberCategory = "comgrp";
				}
			}
		} catch (Exception e) {
			System.out.println("isComgrpChangePw 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return isDeleteMemberCategory;
	}

	//일반회원 회원탈퇴
	public int isNormalMemberDelete(String id) {
		int normalMemberDeleteCount = 0;
		try {
			sql = "delete from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			normalMemberDeleteCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isNormalMemberDelete 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return normalMemberDeleteCount;
	}

	//기업/단체회원 회원탈퇴
	public int isComgrpMemberDelete(String id) {
		int comgrpMemberDeleteCount = 0;
		try {
			sql = "delete from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			
			comgrpMemberDeleteCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isComgrpMemberDelete 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return comgrpMemberDeleteCount;
	}

	//일반회원 개인정보 수정
	public int isupdateNormalMember(NormalMemberBean normalMemberUpdate) {
		int normalMemberUpdateCount = 0;
		try {
			sql = "update normal_member_tbl set normal_member_name = ?, normal_member_phone = ?, normal_member_birth = ?, normal_member_email = ?, normal_member_gender = ? where normal_member_id = '" + normalMemberUpdate.getNormal_member_id() + "'";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, normalMemberUpdate.getNormal_member_name());
			pstmt.setString(2, normalMemberUpdate.getNormal_member_phone());
			pstmt.setString(3, normalMemberUpdate.getNormal_member_birth());
			pstmt.setString(4, normalMemberUpdate.getNormal_member_email());
			pstmt.setString(5, normalMemberUpdate.getNormal_member_gender());
			
			normalMemberUpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isupdateNormalMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return normalMemberUpdateCount;
	}

	//기업/단체회원 개인정보 수정
	public int isupdateComgrpMember(CompanyGroupMemberBean companyGroupMemberBean) {
		int comgrpMemberUpdateCount = 0;
		try {
			sql = "update comgrp_member_tbl set comgrp_member_category = ?, comgrp_member_name = ?, comgrp_manager_name = ?, comgrp_member_companyno = ?, comgrp_manager_phone = ?, comgrp_member_email = ? where comgrp_member_id = '" + companyGroupMemberBean.getComgrp_member_id() + "'";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, companyGroupMemberBean.getComgrp_member_category());
			pstmt.setString(2, companyGroupMemberBean.getComgrp_member_name());
			pstmt.setString(3, companyGroupMemberBean.getComgrp_manager_name());
			pstmt.setString(4, companyGroupMemberBean.getComgrp_member_companyno());
			pstmt.setString(5, companyGroupMemberBean.getComgrp_manager_phone());
			pstmt.setString(6, companyGroupMemberBean.getComgrp_member_email());
			
			comgrpMemberUpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("isupdateComgrpMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return comgrpMemberUpdateCount;
	}

	//비밀번호 변경 전 회원구분
	public String isChangePwMemberCategory(String id) {
		String isChangePwMemberCategory = "";
		try {
			sql = "select normal_member_pw from normal_member_tbl where normal_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
					isChangePwMemberCategory = "normal";
			} else {
				sql = "select comgrp_member_pw from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
						isChangePwMemberCategory = "comgrp";
				}
			}
		} catch (Exception e) {
			System.out.println("isChangePwMemberCategory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return isChangePwMemberCategory;
	}

}

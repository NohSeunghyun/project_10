package vo.donation;

public class DonationBankBean {
	private int donation_no;
	private String bank_category;
	private String bank_proprietor;
	private String bank_name;
	private String pay_date;
	
	public int getDonation_no() {
		return donation_no;
	}
	public void setDonation_no(int donation_no) {
		this.donation_no = donation_no;
	}
	public String getBank_proprietor() {
		return bank_proprietor;
	}
	public void setBank_proprietor(String bank_proprietor) {
		this.bank_proprietor = bank_proprietor;
	}
	public String getBank_name() {
		return bank_name;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public String getPay_date() {
		return pay_date;
	}
	public void setPay_date(String pay_date) {
		this.pay_date = pay_date;
	}
	public String getBank_category() {
		return bank_category;
	}
	public void setBank_category(String bank_category) {
		this.bank_category = bank_category;
	}
}

package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;
import vo.campaign.CampaignBean;

public class CampaignInsertService {

	//캠페인 등록 Service
	public boolean campaignInsert(CampaignBean campaignBean) {
		boolean isCampaignInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int insertCount = campaignDAO.campaignInsert(campaignBean);
			
			if (insertCount > 0) {
				commit(con);
				isCampaignInsertSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("campaignInsertService 에러" + e);
		} finally {
			close(con);
		}
		return isCampaignInsertSuccess;
	}

}

package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;

public class SupportGorupDeleteService {

	//캠페인 지원 단체 삭제 Service
	public boolean isSupportGroupDelete(int group_no) {
		boolean isSupportGroupDeleteSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int deleteCount = campaignDAO.supportGroupDelete(group_no);
			
			if (deleteCount > 0) {
				commit(con);
				isSupportGroupDeleteSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isCampaignDeleteService 에러" + e);
		} finally {
			close(con);
		}
		return isSupportGroupDeleteSuccess;
	}

}

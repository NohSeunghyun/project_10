package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.DonationDAO;

public class MyDonationInfoService {

	//나의 총 후원금 가져오기 Service
	public String getMyDonationMoney(String id, int campaign_no) {
		String money = "";
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			money = donationDAO.getMyDonationMoney(id, campaign_no);
		} catch (Exception e) {
			System.out.println("getMyDonationMoneyService 에러" + e);
		} finally {
			close(con);
		}
		return money;
	}

}

package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.DonationDAO;
import vo.donation.DonationBean;

public class DonationInfoService {

	//일반회원 기부번호 가져오기 Service
	public int getNormalMemberDonationNo() {
		int donation_no = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			donation_no = donationDAO.getNormalMemberDonationNo();
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationNoService 에러" + e);
		} finally {
			close(con);
		}
		return donation_no;
	}
	
	//기업/단체회원 기부번호 가져오기 Service
	public int getComgrpMemberDonationNo() {
		int donation_no = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			donation_no = donationDAO.getComgrpMemberDonationNo();
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationNoService 에러" + e);
		} finally {
			close(con);
		}
		return donation_no;
	}

	//일반회원 기부내역 가져오기 Service
	public ArrayList<DonationBean> getNormalMemberDonationInfo() {
		ArrayList<DonationBean> normalDonationInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalDonationInfo = donationDAO.getNormalMemberDonationInfo();
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationInfoService 에러" + e);
		} finally {
			close(con);
		}
		return normalDonationInfo;
	}

	//기업/단체회원 기부내역 가져오기 Service
	public ArrayList<DonationBean> getComgrpMemberDonationInfo() {
		ArrayList<DonationBean> comgrpDonationInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpDonationInfo = donationDAO.getComgrpMemberDonationInfo();
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationInfoService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpDonationInfo;
	}

	//관리자 단체회원 지원단체 신청 승인 전 신청단체 가져오기 Service
	public ArrayList<DonationBean> getSupportGroupApplicationList() {
		ArrayList<DonationBean> supportGroupApplicationList = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			supportGroupApplicationList = donationDAO.getSupportGroupApplicationList();
		} catch (Exception e) {
			System.out.println("getSupportGroupApplicationListService 에러" + e);
		} finally {
			close(con);
		}	
		return supportGroupApplicationList;
	}

}

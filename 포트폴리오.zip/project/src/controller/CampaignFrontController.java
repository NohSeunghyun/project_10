package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import action.campaign.CampaignInsertAdminGradeChkProAction;
import action.campaign.CampaignInsertProAction;
import action.campaign.CampaignListProAction;
import action.campaign.CampaignSupportGroupListProAction;
import action.campaign.CampaignUpdateImageAdminGradeChkProAction;
import action.campaign.CampaignUpdateProAction;
import action.campaign.SupportGroupUpdateAdminGradeChkProAction;
import action.campaign.SupportUpdateProAction;
import action.campaign.campaignSupprotGrantHistoryProAction;
import action.campaign.supportGroupApplicationApproveListProAction;
import action.campaign.supportGroupApplicationApproveProAction;
import action.campaign.supportGroupApplicationGetGroupNameProAction;
import action.campaign.supportGroupApplicationProAction;
import action.campaign.GrantSendAdminGradeChkProAction;
import action.campaign.GrantSendProAction;
import action.campaign.SupportGroupDeleteProAction;
import action.campaign.SupportGroupInsertAdminGradeChkProAction;
import action.campaign.SupportGroupInsertProAction;
import action.campaign.SupportGroupIntroProAction;
import action.campaign.CampaignChangeImageProAction;
import action.campaign.CampaignDeleteProAction;
import action.campaign.CampaignDetailListProAction;
import action.campaign.CampaignInfoProAction;
import vo.ActionForward;

/**
 * Servlet implementation class CampaignController
 */
@WebServlet("*.campaign")
public class CampaignFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CampaignFrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		Action action = null;
		ActionForward forward = null;
		
		if (command.equals("/campaign.campaign")) {//캠페인 목록보기 요청 처리
			action = new CampaignListProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignInsertAdminGradeChk.campaign")) {//관리자 캠페인 등록 전 관리자 등급 확인 처리
			action = new CampaignInsertAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignInsert.campaign")) {//관리자 캠페인 등록 처리
			action = new CampaignInsertProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignDelete.campaign")) {//관리자 캠페인 삭제 처리
			action = new CampaignDeleteProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignInfo.campaign")) {//관리자 캠페인 수정(제목,내용) 전 정보조회 처리
			action = new CampaignInfoProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignUpdate.campaign")) {//관리자 캠페인 수정(제목,내용) 처리
			action = new CampaignUpdateProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignUpdateImageAdminGradeChk.campaign")) {//관리자 캠페인 수정 전 관리자 등급 확인 처리
			action = new CampaignUpdateImageAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignChangeImage.campaign")) {//관리자 캠페인 수정(사진) 처리
			action = new CampaignChangeImageProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignDetailList.campaign")) {//캠페인 세부목록보기 요청 처리
			action = new CampaignDetailListProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupUpdateAdminGradeChk.campaign")) {//관리자 지원단체 수정 전 관리자 등급 확인 처리
			action = new SupportGroupUpdateAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportUpdate.campaign")) {//관리자 지원단체 수정 처리
			action = new SupportUpdateProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupDelete.campaign")) {//관리자 지원단체 삭제 처리
			action = new SupportGroupDeleteProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupInsertAdminGradeChk.campaign")) {//관리자 지원단체 추가 전 관리자 등급 확인 처리
			action = new SupportGroupInsertAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupInsert.campaign")) {//관리자 지원단체 추가 처리
			action = new SupportGroupInsertProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/grantSendAdminGradeChk.campaign")) {//관리자 지원단체 지원금 전송 전 관리자 등급 확인 처리
			action = new GrantSendAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/grantSend.campaign")) {//관리자 지원단체 지원금 전송 처리
			action = new GrantSendProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupIntro.campaign")) {//지원단체 소개 화면 이동 및 정보 조회 처리
			action = new SupportGroupIntroProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignSupportGroupList.campaign")) {//캠페인 별 지원단체 목록보기 요청 처리
			action = new CampaignSupportGroupListProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/campaignSupprotGrantHistory.campaign")) {//캠페인 별 지원단체 지원현황 보기 요청 처리
			action = new campaignSupprotGrantHistoryProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupApplicationGetGroupName.campaign")) {//단체회원 지원단체 신청 전 단체이름 가져오기 처리
			action = new supportGroupApplicationGetGroupNameProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupApplication.campaign")) {//단체회원 지원단체 신청 처리
			action = new supportGroupApplicationProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupApplicationApproveList.campaign")) {//관리자 단체회원 지원단체 신청 승인 전 신청단체 가져오기 및 관리자등급 체크 처리
			action = new supportGroupApplicationApproveListProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/supportGroupApplicationApprove.campaign")) {//관리자 단체회원 지원단체 신청 승인 처리
			action = new supportGroupApplicationApproveProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		/******************************포워딩******************************/
		
		if(forward != null) {
			if(forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
			} else {
			request.getRequestDispatcher(forward.getPath()).forward(request, response);
			}
		}
	}
}

package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vo.ActionForward;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("*.page")
public class PageFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PageFrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		ActionForward forward = null;
		
		if (command.equals("/mainPage.page")) {//메인페이지 이동
			forward = new ActionForward("index.jsp", false);
		}
		else if (command.equals("/loginFrom.page")) {//로그인 화면
			forward = new ActionForward("/login/loginForm.jsp", false);
		}
		else if (command.equals("/memberLogin.page")) {//일반,기업/단체 회원 로그인성공 index 화면
			forward = new ActionForward("/member/index.jsp", false);
		}
		else if (command.equals("/adminLogin.page")) {//관리자 로그인성공 index 화면
			forward = new ActionForward("/admin/index.jsp", false);
		}
		else if (command.equals("/checkCategoryForm.page")) {//회원가입 전 일반,기업/단체 구분 체크 화면
			forward = new ActionForward("/login/checkCategory.jsp", false);
		}
		else if (command.equals("/joinMemberShip_normal_Form.page")) {//일반회원 회원가입 화면
			forward = new ActionForward("/login/joinMemberShip_normal_Form.jsp", false);
		}
		else if (command.equals("/joinMemberShip_comgrp_Form.page")) {//기업/단체 회원가입 화면
			forward = new ActionForward("/login/joinMemberShip_comgrp_Form.jsp", false);
		}
		else if (command.equals("/idOverlapCheckForm.page")) {//아이디 중복 체크  화면 
			forward = new ActionForward("/login/idOverlapChkForm.jsp", false);
		}
		else if (command.equals("/idOverlapCheckSuccessForm.page")) {//아이디 중복 성공 후  화면 
			forward = new ActionForward("/login/idOverlapChkSuccess.jsp", false);
		}
		else if (command.equals("/joinMemberShipSuccess.page")) {//회원가입 성공 후 로그인 화면
			forward = new ActionForward("/alert/joinMemberShip_Success.jsp", false);
		}
		else if (command.equals("/searchIDForm.page")) {//아이디 찾기 화면
			forward = new ActionForward("/login/searchIDForm.jsp", false);
		}
		else if (command.equals("/phone_searchID_Form.page")) {//핸드폰번호로 아이디 찾기 화면
			forward = new ActionForward("/login/phone_searchIDForm.jsp", false);
		}
		else if (command.equals("/email_searchID_Form.page")) {//이메일주소로 아이디 찾기 화면
			forward = new ActionForward("/login/email_searchIDForm.jsp", false);
		}
		else if (command.equals("/searchPWForm.page")) {//비밀번호 찾기 화면
			forward = new ActionForward("/login/searchPWForm.jsp", false);
		}
		else if (command.equals("/personalInformation.page")) {//개인정보조회 전 비밀번호 확인 화면
			forward = new ActionForward("/member/personalInformationChkPW.jsp", false);
		}
		else if (command.equals("/normalMemberPersonalInformationForm.page")) {//일반회원 개인정보조회 화면
			forward = new ActionForward("/member/normalMemberPersonalInformationForm.jsp", false);
		}
		else if (command.equals("/comgrpMemberPersonalInformationForm.page")) {//기업/단체 회원 개인정보조회 화면
			forward = new ActionForward("/member/comgrpMemberPersonalInformationForm.jsp", false);
		}
		else if (command.equals("/changeNameForm.page")) {//개인정보 이름 변경 화면
			forward = new ActionForward("/member/changeNameForm.jsp", false);
		}
		else if (command.equals("/changePhoneForm.page")) {//개인정보 휴대폰번호 변경 화면
			forward = new ActionForward("/member/changePhoneForm.jsp", false);
		}
		else if (command.equals("/changeEmailForm.page")) {//개인정보 이메일 변경 화면
			forward = new ActionForward("/member/changeEmailForm.jsp", false);
		}
		else if (command.equals("/changePWForm.page")) {//개인정보 비밀번호 변경 화면
			forward = new ActionForward("/member/changePWForm.jsp", false);
		}
		else if (command.equals("/changePWForm2.page")) {//비밀번호 찾기 후 비밀번호 변경 화면
			forward = new ActionForward("/member/changePWForm2.jsp", false);
		}
		else if (command.equals("/changeComgrpNameForm.page")) {//개인정보 기업/단체명 변경 화면
			forward = new ActionForward("/member/changeComgrpNameForm.jsp", false);
		}
		else if (command.equals("/changeCompanynoForm.page")) {//개인정보 사업자번호 변경 화면
			forward = new ActionForward("/member/changeCompanynoForm.jsp", false);
		}
		else if (command.equals("/deleteSuccess.page")) {//회원탈퇴 후 알람화면
			forward = new ActionForward("/alert/deleteAlert.jsp", false);
		}
		else if (command.equals("/changePwSuccess.page")) {//비밀번호 변경 후 알람화면
			forward = new ActionForward("/alert/changePwAlert.jsp", false);
		}
		else if (command.equals("/memberUpdateSuccess.page")) {//개인정보 수정 후 알람화면
			forward = new ActionForward("/alert/memberUpdateAlert.jsp", false);
		}
		else if (command.equals("/allMemberPersonalInformation.page")) {//관리자 전체회원정보조회 전 본인확인 화면
			forward = new ActionForward("/admin/allMemberPersonalInformationChkPwPhone.jsp", false);
		}
		else if (command.equals("/allMemberPersonalInformationForm.page")) {//관리자 전체회원정보조회 화면
			forward = new ActionForward("/admin/allMemberPersonalInformationForm.jsp", false);
		}
		else if (command.equals("/searchIdMemberInfo.page")) {//관리자 회원아이디로 회원정보 검색결과 화면
			forward = new ActionForward("/admin/searchIdMemberInfoForm.jsp", false);
		}
		else if (command.equals("/memberChangePwForm.page")) {//관리자 회원비밀번호변경 화면
			forward = new ActionForward("/admin/memberChangePwForm.jsp", false);
		}
		else if (command.equals("/memberChangePwSuccess.page")) {//관리자 회원비밀번호변경 후 알람화면
			forward = new ActionForward("/alert/memberChangePwAlert.jsp", false);
		}
		else if (command.equals("/memberChangeGradeForm.page")) {//관리자 회원등급변경 화면
			forward = new ActionForward("/admin/memberChangeGradeForm.jsp", false);
		}
		else if (command.equals("/memberChangeGradeSuccess.page")) {//관리자 회원등급변경 후 알람화면
			forward = new ActionForward("/alert/memberChangeGradeAlert.jsp", false);
		}
		else if (command.equals("/normalMemberChangeInfoForm.page")) {//관리자 일반회원 정보수정 화면
			forward = new ActionForward("/admin/normalMemberChangeInfoForm.jsp", false);
		}
		else if (command.equals("/normalMemberDeleteForm.page")) {//관리자 일반회원 삭제 화면
			forward = new ActionForward("/admin/normalMemberDeleteForm.jsp", false);
		}
		else if (command.equals("/comgrpMemberChangeInfoForm.page")) {//관리자 기업/단체회원 정보수정 화면
			forward = new ActionForward("/admin/comgrpMemberChangeInfoForm.jsp", false);
		}
		else if (command.equals("/comgrpMemberDeleteForm.page")) {//관리자 기업/단체회원 삭제 화면
			forward = new ActionForward("/admin/comgrpMemberDeleteForm.jsp", false);
		}
		else if (command.equals("/admin_MemberUpdateSuccess.page")) {//관리자 회원정보수정 후 알람화면
			forward = new ActionForward("/alert/admin_MemberUpdateAlert.jsp", false);
		}
		else if (command.equals("/adminChangePwForm.page")) {//관리자 비밀번호변경 화면
			forward = new ActionForward("/admin/adminMemberChangePwForm.jsp", false);
		}
		else if (command.equals("/admin_MeChangePwSuccess.page")) {//관리자 본인 비밀번호변경 후 알람화면
			forward = new ActionForward("/alert/admin_MeChangePwAlert.jsp", false);
		}
		else if (command.equals("/adminChangeGradeForm.page")) {//관리자 등급변경 화면
			forward = new ActionForward("/admin/adminMemberChangeGradeForm.jsp", false);
		}
		else if (command.equals("/admin_MeChangeGradeSuccess.page")) {//관리자 본인 등급변경 후 알람화면
			forward = new ActionForward("/alert/admin_MeChangeGradeAlert.jsp", false);
		}
		else if (command.equals("/adminChangeInfoForm.page")) {//관리자 정보수정 화면
			forward = new ActionForward("/admin/adminMemberChangeInfoForm.jsp", false);
		}
		else if (command.equals("/adminDeleteForm.page")) {//관리자 삭제 화면
			forward = new ActionForward("/admin/adminDeleteForm.jsp", false);
		}
		else if (command.equals("/admin_MemberDeleteSuccess.page")) {//관리자 회원/관리자 삭제 후 알람화면
			forward = new ActionForward("/alert/admin_MemberDeleteAlert.jsp", false);
		}
		else if (command.equals("/admin_MeDeleteSuccess.page")) {//관리자 본인 삭제 후 알람화면
			forward = new ActionForward("/alert/admin_MeDeleteAlert.jsp", false);
		}
		else if (command.equals("/joinMemberShip_admin.page")) {//관리자 추가 화면
			forward = new ActionForward("/admin/joinMemberShip_adminForm.jsp", false);
		}
		else if (command.equals("/joinMemberShip_adminSuccess.page")) {//관리자 추가 후 알람화면
			forward = new ActionForward("/alert/joinMemberShip_adminAlert.jsp", false);
		}
		else if (command.equals("/adminCampaign.page")) {//관리자 캠페인 목록보기 화면
			forward = new ActionForward("/admin/adminCampaignForm.jsp", false);
		}
		else if (command.equals("/memberCampaign.page")) {//회원 캠페인 목록보기 화면
			forward = new ActionForward("/member/memberCampaignForm.jsp", false);
		}
		else if (command.equals("/campaign.page")) {//비회원 캠페인 목록보기 화면
			forward = new ActionForward("campaignForm.jsp", false);
		}
		else if (command.equals("/campaignInsertForm.page")) {//관리자 캠페인 등록 화면
			forward = new ActionForward("/admin/campaignInsertForm.jsp", false);
		}
		else if (command.equals("/campaignInsertSuccess.page")) {//관리자 캠페인 등록 후 알람화면
			forward = new ActionForward("/alert/campaignInsertSuccess.jsp", false);
		}
		else if (command.equals("/campaignDeleteForm.page")) {//관리자 캠페인 삭제 화면
			forward = new ActionForward("/admin/campaignDeleteForm.jsp", false);
		}
		else if (command.equals("/campaignDeleteSuccess.page")) {//관리자 캠페인 삭제 후 알람화면
			forward = new ActionForward("/alert/campaignDeleteSuccess.jsp", false);
		}
		else if (command.equals("/campaignInfoForm.page")) {//관리자 캠페인 수정(제목,내용) 화면
			forward = new ActionForward("/admin/campaignUpdateForm.jsp", false);
		}
		else if (command.equals("/campaignChangeImageForm.page")) {//관리자 캠페인 수정(사진) 화면
			forward = new ActionForward("/admin/campaignChangeImageForm.jsp", false);
		}
		else if (command.equals("/campaignUpdateSuccess.page")) {//관리자 캠페인 수정(제목,내용) 후 알람화면
			forward = new ActionForward("/alert/campaignUpdateSuccess.jsp", false);
		}
		else if (command.equals("/campaignChangeImageSuccess.page")) {//관리자 캠페인 수정(사진) 후 알람화면
			forward = new ActionForward("/alert/campaignChangeImageSuccess.jsp", false);
		}
		else if (command.equals("/adminCampaignDetailList.page")) {//관리자 캠페인 지원단체 목록보기 화면
			forward = new ActionForward("/admin/adminCampaignDetailListForm.jsp", false);
		}
		else if (command.equals("/memberCampaignDetailList.page")) {//회원 캠페인 지원단체 목록보기 화면
			forward = new ActionForward("/member/memberCampaignDetailListForm.jsp", false);
		}
		else if (command.equals("/campaignDetailList.page")) {//비회원 캠페인 지원단체 목록보기 화면
			forward = new ActionForward("campaignDetailListForm.jsp", false);
		}
		else if (command.equals("/campaignDetailGroupInfoForm.page")) {//관리자 지원단체 수정 화면
			forward = new ActionForward("/admin/campaignDetailUpdateForm.jsp", false);
		}
		else if (command.equals("/supportUpdateSuccess.page")) {//관리자 지원단체 수정 후 알람화면
			forward = new ActionForward("/alert/supportUpdateSuccess.jsp", false);
		}
		else if (command.equals("/supportGroupDeleteForm.page")) {//관리자 지원단체 삭제 화면
			forward = new ActionForward("/admin/supportGroupDeleteForm.jsp", false);
		}
		else if (command.equals("/supportGroupDeleteSuccess.page")) {//관리자 지원단체 삭제 후 알람화면
			forward = new ActionForward("/alert/supportGroupDeleteSuccess.jsp", false);
		}
		else if (command.equals("/supportGroupInsertForm.page")) {//관리자 지원단체 추가 화면
			forward = new ActionForward("/admin/supportGroupInsertForm.jsp", false);
		}
		else if (command.equals("/supportGroupInsertSuccess.page")) {//관리자 지원단체 추가 후 알람화면
			forward = new ActionForward("/alert/supportGroupInsertSuccess.jsp", false);
		}
		else if (command.equals("/grantSendForm.page")) {//관리자 지원단체 지원금 전송 화면
			forward = new ActionForward("/admin/grantSendForm.jsp", false);
		}
		else if (command.equals("/grantSendSuccess.page")) {//관리자 지원단체 지원금 전송 후 알람화면
			forward = new ActionForward("/alert/grantSendSuccess.jsp", false);
		}
		else if (command.equals("/adminSupportGroupIntro.page")) {//관리자 지원단체 소개화면
			forward = new ActionForward("/admin/supportGroupIntro.jsp", false);
		}
		else if (command.equals("/memberSupportGroupIntro.page")) {//회원 지원단체 소개화면
			forward = new ActionForward("/member/supportGroupIntro.jsp", false);
		}
		else if (command.equals("/supportGroupIntro.page")) {//비회원 지원단체 소개화면
			forward = new ActionForward("supportGroupIntro.jsp", false);
		}
		else if (command.equals("/campaignSupportGroupListAdmin.page")) {//관리자 캠페인별 지원단체 목록 화면
			forward = new ActionForward("/admin/campaignSupportGroupList.jsp", false);
		}
		else if (command.equals("/campaignSupportGroupListMember.page")) {//회원 캠페인별 지원단체 목록 화면
			forward = new ActionForward("/member/campaignSupportGroupList.jsp", false);
		}
		else if (command.equals("/campaignSupportGroupList.page")) {//비회원 캠페인별 지원단체 목록 화면
			forward = new ActionForward("campaignSupportGroupList.jsp", false);
		}
		else if (command.equals("/campaignSupprotGrantHistoryAdmin.page")) {//관리자 캠페인별 지원단체 지원현황 화면
			forward = new ActionForward("/admin/campaignSupprotGrantHistory.jsp", false);
		}
		else if (command.equals("/campaignSupprotGrantHistoryMember.page")) {//회원 캠페인별 지원단체 지원현황 화면
			forward = new ActionForward("/member/campaignSupprotGrantHistory.jsp", false);
		}
		else if (command.equals("/campaignSupprotGrantHistory.page")) {//비회원 캠페인별 지원단체 지원현황 화면
			forward = new ActionForward("campaignSupprotGrantHistory.jsp", false);
		}
		else if (command.equals("/donationForm.page")) {//기부 정보 화면
			forward = new ActionForward("/member/donationForm.jsp", false);
		}
		else if (command.equals("/accountCertification.page")) {//계좌인증 화면
			forward = new ActionForward("/alert/accountCertificationSuccess.jsp", false);
		}
		else if (command.equals("/donationSuccess.page")) {//기부 후 알람화면
			forward = new ActionForward("/alert/donationSuccess.jsp", false);
		}
		else if (command.equals("/donationHistoryAdmin.page")) {//관리자 기부내역 화면
			forward = new ActionForward("/admin/donationHistory.jsp", false);
		}
		else if (command.equals("/donationHistoryMember.page")) {//회원 기부내역 화면
			forward = new ActionForward("/member/donationHistory.jsp", false);
		}
		else if (command.equals("/donationHistory.page")) {//비회원 기부내역 화면
			forward = new ActionForward("donationHistory.jsp", false);
		}
		else if (command.equals("/supportGroupApplication.page")) {//단체회원 캠페인 지원단체 신청 화면
			forward = new ActionForward("/member/supportGroupApplicationForm.jsp", false);
		}
		else if (command.equals("/supportGroupApplicationSuccess.page")) {//단체회원 캠페인 지원단체 신청 후 알람화면
			forward = new ActionForward("/alert/supportGroupApplicationSuccess.jsp", false);
		}
		else if (command.equals("/supportGroupApplicationForm.page")) {//관리자 단체회원 캠페인 지원단체 추가 승인 화면
			forward = new ActionForward("/admin/supportGroupApplicationForm.jsp", false);
		}
		else if (command.equals("/supportGroupApplicationApproveSuccess.page")) {//관리자 단체회원 캠페인 지원단체 추가 승인 후 알람화면
			forward = new ActionForward("/alert/supportGroupApplicationApproveSuccess.jsp", false);
		}
		else if (command.equals("/forLogin.page")) {//로그인 필요한 화면 알람화면
			forward = new ActionForward("/alert/forLogin.jsp", false);
		}
		
		/******************************포워딩******************************/
		
		if(forward != null) {
			if(forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
			} else {
			request.getRequestDispatcher(forward.getPath()).forward(request, response);
			}
		}
	}
}


